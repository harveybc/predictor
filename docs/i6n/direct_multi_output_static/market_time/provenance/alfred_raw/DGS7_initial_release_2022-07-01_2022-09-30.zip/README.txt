-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:32 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2022-06-13
2022-06-14
2022-06-15
2022-06-16
2022-06-17
2022-06-21
2022-06-22
2022-06-23
2022-06-24
2022-06-27
2022-06-28
2022-06-29
2022-06-30
2022-07-01
2022-07-05
2022-07-06
2022-07-07
2022-07-08
2022-07-11
2022-07-12
2022-07-13
2022-07-14
2022-07-15
2022-07-18
2022-07-19
2022-07-20
2022-07-21
2022-07-22
2022-07-25
2022-07-26
2022-07-27
2022-07-28
2022-07-29
2022-08-01
2022-08-02
2022-08-03
2022-08-04
2022-08-05
2022-08-08
2022-08-09
2022-08-10
2022-08-11
2022-08-12
2022-08-15
2022-08-16
2022-08-17
2022-08-18
2022-08-19
2022-08-22
2022-08-23
2022-08-24
2022-08-25
2022-08-26
2022-08-29
2022-08-30
2022-08-31
2022-09-01
2022-09-02
2022-09-06
2022-09-07
2022-09-08
2022-09-09
2022-09-12
2022-09-13
2022-09-14
2022-09-15
2022-09-16
2022-09-19
2022-09-20
2022-09-21
2022-09-22
2022-09-23
2022-09-26
2022-09-27
2022-09-28
2022-09-29
2022-09-30
2022-10-03
2022-10-04
2022-10-05
2022-10-06
2022-10-07
2022-10-11
2022-10-12
2022-10-13
2022-10-14
2022-10-17
2022-10-18
2022-10-19
2022-10-20
----------

