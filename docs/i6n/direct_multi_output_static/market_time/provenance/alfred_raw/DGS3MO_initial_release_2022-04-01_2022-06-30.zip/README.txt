-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2022-03-14
2022-03-15
2022-03-16
2022-03-17
2022-03-18
2022-03-21
2022-03-22
2022-03-23
2022-03-24
2022-03-25
2022-03-28
2022-03-29
2022-03-30
2022-03-31
2022-04-01
2022-04-04
2022-04-05
2022-04-06
2022-04-07
2022-04-08
2022-04-11
2022-04-12
2022-04-13
2022-04-14
2022-04-15
2022-04-19
2022-04-20
2022-04-21
2022-04-22
2022-04-25
2022-04-26
2022-04-27
2022-04-28
2022-04-29
2022-05-02
2022-05-03
2022-05-04
2022-05-05
2022-05-06
2022-05-09
2022-05-10
2022-05-11
2022-05-12
2022-05-13
2022-05-16
2022-05-17
2022-05-18
2022-05-19
2022-05-20
2022-05-23
2022-05-24
2022-05-25
2022-05-26
2022-05-27
2022-05-31
2022-06-01
2022-06-02
2022-06-03
2022-06-06
2022-06-07
2022-06-08
2022-06-09
2022-06-10
2022-06-13
2022-06-14
2022-06-15
2022-06-16
2022-06-17
2022-06-21
2022-06-22
2022-06-23
2022-06-24
2022-06-27
2022-06-28
2022-06-29
2022-06-30
2022-07-01
2022-07-05
2022-07-06
2022-07-07
2022-07-08
2022-07-11
2022-07-12
2022-07-13
2022-07-14
2022-07-15
2022-07-18
2022-07-19
2022-07-20
----------

