-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2019-03-12
2019-03-13
2019-03-14
2019-03-15
2019-03-18
2019-03-19
2019-03-20
2019-03-21
2019-03-22
2019-03-25
2019-03-26
2019-03-27
2019-03-28
2019-03-29
2019-04-01
2019-04-02
2019-04-03
2019-04-04
2019-04-05
2019-04-08
2019-04-09
2019-04-10
2019-04-11
2019-04-12
2019-04-15
2019-04-16
2019-04-17
2019-04-18
2019-04-19
2019-04-23
2019-04-24
2019-04-25
2019-04-26
2019-04-29
2019-04-30
2019-05-01
2019-05-02
2019-05-03
2019-05-06
2019-05-07
2019-05-08
2019-05-09
2019-05-10
2019-05-13
2019-05-14
2019-05-15
2019-05-16
2019-05-17
2019-05-20
2019-05-21
2019-05-22
2019-05-23
2019-05-24
2019-05-28
2019-05-29
2019-05-30
2019-05-31
2019-06-03
2019-06-04
2019-06-05
2019-06-06
2019-06-07
2019-06-10
2019-06-11
2019-06-12
2019-06-13
2019-06-14
2019-06-17
2019-06-18
2019-06-19
2019-06-20
2019-06-21
2019-06-24
2019-06-25
2019-06-26
2019-06-27
2019-06-28
2019-07-01
2019-07-02
2019-07-03
2019-07-05
2019-07-08
2019-07-09
2019-07-10
2019-07-11
2019-07-12
2019-07-15
2019-07-16
2019-07-17
2019-07-18
2019-07-19
----------

