-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2019-09-11
2019-09-12
2019-09-13
2019-09-16
2019-09-17
2019-09-18
2019-09-19
2019-09-20
2019-09-23
2019-09-24
2019-09-25
2019-09-26
2019-09-27
2019-09-30
2019-10-01
2019-10-02
2019-10-03
2019-10-04
2019-10-07
2019-10-08
2019-10-09
2019-10-10
2019-10-11
2019-10-15
2019-10-16
2019-10-17
2019-10-18
2019-10-21
2019-10-22
2019-10-23
2019-10-24
2019-10-25
2019-10-28
2019-10-29
2019-10-30
2019-10-31
2019-11-01
2019-11-04
2019-11-05
2019-11-06
2019-11-07
2019-11-08
2019-11-12
2019-11-13
2019-11-14
2019-11-15
2019-11-18
2019-11-19
2019-11-20
2019-11-21
2019-11-22
2019-11-25
2019-11-26
2019-11-27
2019-11-29
2019-12-02
2019-12-03
2019-12-04
2019-12-05
2019-12-06
2019-12-09
2019-12-10
2019-12-11
2019-12-12
2019-12-13
2019-12-16
2019-12-17
2019-12-18
2019-12-19
2019-12-20
2019-12-23
2019-12-26
2019-12-27
2019-12-30
2019-12-31
2020-01-02
2020-01-03
2020-01-06
2020-01-07
2020-01-08
2020-01-09
2020-01-10
2020-01-13
2020-01-14
2020-01-15
2020-01-16
2020-01-17
----------

