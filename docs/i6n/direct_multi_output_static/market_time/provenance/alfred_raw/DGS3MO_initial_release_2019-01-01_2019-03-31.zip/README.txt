-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:30 PM CDT
-------------------------------------------------------------------

------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                             Real-Time Start  Real-Time End
3-Month Treasury Constant Maturity Rate                                                           2005-06-28       2019-06-30
Source
Board of Governors of the Federal Reserve System (US)                                             2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                      2005-06-28       Current
Units
Percent                                                                                           2005-06-28       Current
Frequency
Daily                                                                                             2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                           2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                2005-06-28       2019-06-30
please refer to
http://www.federalreserve.gov/releases/h15/current/h15.pdf and
http://www.treasury.gov/resource-center/data-chart-center/interest-rates/Pages/yieldmethod.aspx.
------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2018-12-12
2018-12-13
2018-12-14
2018-12-17
2018-12-18
2018-12-19
2018-12-20
2018-12-21
2018-12-26
2018-12-27
2018-12-28
2018-12-31
2019-01-02
2019-01-03
2019-01-04
2019-01-07
2019-01-08
2019-01-09
2019-01-10
2019-01-11
2019-01-15
2019-01-16
2019-01-17
2019-01-18
2019-01-22
2019-01-23
2019-01-24
2019-01-25
2019-01-28
2019-01-29
2019-01-30
2019-01-31
2019-02-01
2019-02-04
2019-02-05
2019-02-06
2019-02-07
2019-02-08
2019-02-11
2019-02-12
2019-02-13
2019-02-14
2019-02-15
2019-02-19
2019-02-21
2019-02-22
2019-02-25
2019-02-26
2019-02-27
2019-02-28
2019-03-01
2019-03-04
2019-03-05
2019-03-06
2019-03-07
2019-03-08
2019-03-11
2019-03-12
2019-03-13
2019-03-14
2019-03-15
2019-03-18
2019-03-19
2019-03-20
2019-03-21
2019-03-22
2019-03-25
2019-03-26
2019-03-27
2019-03-28
2019-03-29
2019-04-01
2019-04-02
2019-04-03
2019-04-04
2019-04-05
2019-04-08
2019-04-09
2019-04-10
2019-04-11
2019-04-12
2019-04-15
2019-04-16
2019-04-17
2019-04-18
2019-04-19
----------

