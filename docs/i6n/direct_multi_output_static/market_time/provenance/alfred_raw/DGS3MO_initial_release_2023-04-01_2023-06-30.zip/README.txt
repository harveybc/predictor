-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2023-03-13
2023-03-14
2023-03-15
2023-03-16
2023-03-17
2023-03-20
2023-03-21
2023-03-22
2023-03-23
2023-03-24
2023-03-27
2023-03-28
2023-03-29
2023-03-30
2023-03-31
2023-04-03
2023-04-04
2023-04-05
2023-04-06
2023-04-07
2023-04-10
2023-04-11
2023-04-12
2023-04-13
2023-04-14
2023-04-17
2023-04-18
2023-04-19
2023-04-20
2023-04-21
2023-04-24
2023-04-25
2023-04-26
2023-04-27
2023-04-28
2023-05-01
2023-05-02
2023-05-03
2023-05-04
2023-05-05
2023-05-08
2023-05-09
2023-05-10
2023-05-11
2023-05-12
2023-05-15
2023-05-16
2023-05-17
2023-05-18
2023-05-19
2023-05-22
2023-05-23
2023-05-24
2023-05-25
2023-05-26
2023-05-30
2023-05-31
2023-06-01
2023-06-02
2023-06-05
2023-06-06
2023-06-07
2023-06-08
2023-06-09
2023-06-12
2023-06-13
2023-06-14
2023-06-15
2023-06-16
2023-06-20
2023-06-21
2023-06-22
2023-06-23
2023-06-26
2023-06-27
2023-06-28
2023-06-29
2023-06-30
2023-07-03
2023-07-05
2023-07-06
2023-07-07
2023-07-10
2023-07-11
2023-07-12
2023-07-13
2023-07-14
2023-07-17
2023-07-18
2023-07-19
2023-07-20
----------

