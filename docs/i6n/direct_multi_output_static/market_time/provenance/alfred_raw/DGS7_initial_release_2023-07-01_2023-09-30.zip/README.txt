-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:32 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2023-06-12
2023-06-13
2023-06-14
2023-06-15
2023-06-16
2023-06-20
2023-06-21
2023-06-22
2023-06-23
2023-06-26
2023-06-27
2023-06-28
2023-06-29
2023-06-30
2023-07-03
2023-07-05
2023-07-06
2023-07-07
2023-07-10
2023-07-11
2023-07-12
2023-07-13
2023-07-14
2023-07-17
2023-07-18
2023-07-19
2023-07-20
2023-07-21
2023-07-24
2023-07-25
2023-07-26
2023-07-27
2023-07-28
2023-07-31
2023-08-01
2023-08-03
2023-08-04
2023-08-07
2023-08-08
2023-08-09
2023-08-10
2023-08-11
2023-08-14
2023-08-15
2023-08-16
2023-08-17
2023-08-18
2023-08-21
2023-08-22
2023-08-23
2023-08-24
2023-08-25
2023-08-28
2023-08-29
2023-08-30
2023-08-31
2023-09-01
2023-09-05
2023-09-06
2023-09-07
2023-09-08
2023-09-11
2023-09-12
2023-09-14
2023-09-15
2023-09-18
2023-09-19
2023-09-20
2023-09-21
2023-09-22
2023-09-25
2023-09-26
2023-09-27
2023-09-28
2023-09-29
2023-10-02
2023-10-03
2023-10-04
2023-10-05
2023-10-06
2023-10-10
2023-10-11
2023-10-12
2023-10-13
2023-10-16
2023-10-17
2023-10-18
2023-10-19
2023-10-20
----------

