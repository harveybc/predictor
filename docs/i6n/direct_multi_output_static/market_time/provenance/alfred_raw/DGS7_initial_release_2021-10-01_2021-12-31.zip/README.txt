-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2021-09-13
2021-09-14
2021-09-15
2021-09-16
2021-09-17
2021-09-20
2021-09-21
2021-09-22
2021-09-23
2021-09-24
2021-09-27
2021-09-28
2021-09-29
2021-09-30
2021-10-01
2021-10-04
2021-10-05
2021-10-06
2021-10-07
2021-10-08
2021-10-12
2021-10-13
2021-10-14
2021-10-15
2021-10-18
2021-10-19
2021-10-20
2021-10-21
2021-10-22
2021-10-25
2021-10-26
2021-10-27
2021-10-28
2021-10-29
2021-11-01
2021-11-02
2021-11-03
2021-11-04
2021-11-05
2021-11-08
2021-11-09
2021-11-10
2021-11-12
2021-11-15
2021-11-16
2021-11-17
2021-11-18
2021-11-19
2021-11-22
2021-11-23
2021-11-24
2021-11-26
2021-11-29
2021-11-30
2021-12-01
2021-12-02
2021-12-03
2021-12-06
2021-12-07
2021-12-08
2021-12-09
2021-12-10
2021-12-13
2021-12-14
2021-12-15
2021-12-16
2021-12-17
2021-12-20
2021-12-21
2021-12-22
2021-12-23
2021-12-27
2021-12-28
2021-12-29
2021-12-30
2022-01-03
2022-01-04
2022-01-05
2022-01-06
2022-01-07
2022-01-10
2022-01-11
2022-01-12
2022-01-13
2022-01-14
2022-01-18
2022-01-19
2022-01-20
----------

