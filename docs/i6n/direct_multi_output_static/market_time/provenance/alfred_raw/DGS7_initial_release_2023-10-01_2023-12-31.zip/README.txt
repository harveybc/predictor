-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:32 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2023-09-11
2023-09-12
2023-09-14
2023-09-15
2023-09-18
2023-09-19
2023-09-20
2023-09-21
2023-09-22
2023-09-25
2023-09-26
2023-09-27
2023-09-28
2023-09-29
2023-10-02
2023-10-03
2023-10-04
2023-10-05
2023-10-06
2023-10-10
2023-10-11
2023-10-12
2023-10-13
2023-10-16
2023-10-17
2023-10-18
2023-10-19
2023-10-20
2023-10-23
2023-10-24
2023-10-25
2023-10-26
2023-10-27
2023-10-30
2023-10-31
2023-11-01
2023-11-02
2023-11-03
2023-11-06
2023-11-07
2023-11-08
2023-11-09
2023-11-13
2023-11-14
2023-11-15
2023-11-16
2023-11-17
2023-11-20
2023-11-21
2023-11-22
2023-11-24
2023-11-27
2023-11-28
2023-11-29
2023-11-30
2023-12-01
2023-12-04
2023-12-05
2023-12-06
2023-12-07
2023-12-08
2023-12-11
2023-12-12
2023-12-13
2023-12-14
2023-12-15
2023-12-18
2023-12-19
2023-12-20
2023-12-21
2023-12-22
2023-12-26
2023-12-27
2023-12-28
2023-12-29
2024-01-02
2024-01-03
2024-01-04
2024-01-05
2024-01-08
2024-01-09
2024-01-10
2024-01-11
2024-01-12
2024-01-16
2024-01-17
2024-01-18
2024-01-19
----------

