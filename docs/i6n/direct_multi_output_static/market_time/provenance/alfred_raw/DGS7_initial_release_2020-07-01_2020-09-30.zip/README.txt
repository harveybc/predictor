-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2020-06-11
2020-06-12
2020-06-15
2020-06-16
2020-06-17
2020-06-18
2020-06-19
2020-06-22
2020-06-23
2020-06-24
2020-06-25
2020-06-26
2020-06-29
2020-06-30
2020-07-01
2020-07-02
2020-07-06
2020-07-07
2020-07-08
2020-07-09
2020-07-10
2020-07-13
2020-07-14
2020-07-15
2020-07-16
2020-07-17
2020-07-20
2020-07-21
2020-07-22
2020-07-23
2020-07-24
2020-07-27
2020-07-28
2020-07-29
2020-07-30
2020-07-31
2020-08-03
2020-08-04
2020-08-05
2020-08-06
2020-08-07
2020-08-10
2020-08-11
2020-08-12
2020-08-13
2020-08-14
2020-08-17
2020-08-18
2020-08-19
2020-08-21
2020-08-24
2020-08-25
2020-08-26
2020-08-27
2020-08-28
2020-08-31
2020-09-01
2020-09-02
2020-09-03
2020-09-04
2020-09-08
2020-09-09
2020-09-10
2020-09-11
2020-09-14
2020-09-15
2020-09-16
2020-09-17
2020-09-18
2020-09-21
2020-09-22
2020-09-23
2020-09-24
2020-09-25
2020-09-28
2020-09-29
2020-09-30
2020-10-01
2020-10-02
2020-10-05
2020-10-06
2020-10-07
2020-10-08
2020-10-09
2020-10-13
2020-10-14
2020-10-15
2020-10-16
2020-10-19
2020-10-20
----------

