-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2021-06-11
2021-06-14
2021-06-15
2021-06-16
2021-06-17
2021-06-21
2021-06-22
2021-06-23
2021-06-24
2021-06-25
2021-06-28
2021-06-29
2021-06-30
2021-07-01
2021-07-02
2021-07-06
2021-07-07
2021-07-08
2021-07-09
2021-07-12
2021-07-13
2021-07-14
2021-07-15
2021-07-16
2021-07-19
2021-07-20
2021-07-21
2021-07-22
2021-07-23
2021-07-26
2021-07-27
2021-07-28
2021-07-29
2021-07-30
2021-08-02
2021-08-03
2021-08-04
2021-08-05
2021-08-06
2021-08-09
2021-08-10
2021-08-11
2021-08-12
2021-08-13
2021-08-16
2021-08-17
2021-08-18
2021-08-19
2021-08-20
2021-08-23
2021-08-24
2021-08-25
2021-08-26
2021-08-27
2021-08-30
2021-08-31
2021-09-01
2021-09-02
2021-09-03
2021-09-07
2021-09-08
2021-09-09
2021-09-10
2021-09-13
2021-09-14
2021-09-15
2021-09-16
2021-09-17
2021-09-20
2021-09-21
2021-09-22
2021-09-23
2021-09-24
2021-09-27
2021-09-28
2021-09-29
2021-09-30
2021-10-01
2021-10-04
2021-10-05
2021-10-06
2021-10-07
2021-10-08
2021-10-12
2021-10-13
2021-10-14
2021-10-15
2021-10-18
2021-10-19
2021-10-20
----------

