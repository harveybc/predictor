-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:30 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2021-03-12
2021-03-15
2021-03-16
2021-03-17
2021-03-18
2021-03-19
2021-03-22
2021-03-23
2021-03-24
2021-03-25
2021-03-26
2021-03-29
2021-03-30
2021-03-31
2021-04-01
2021-04-02
2021-04-05
2021-04-06
2021-04-07
2021-04-08
2021-04-09
2021-04-12
2021-04-13
2021-04-14
2021-04-15
2021-04-16
2021-04-19
2021-04-20
2021-04-21
2021-04-22
2021-04-23
2021-04-26
2021-04-27
2021-04-28
2021-04-29
2021-04-30
2021-05-03
2021-05-04
2021-05-05
2021-05-06
2021-05-07
2021-05-10
2021-05-11
2021-05-12
2021-05-13
2021-05-14
2021-05-17
2021-05-18
2021-05-19
2021-05-20
2021-05-21
2021-05-24
2021-05-25
2021-05-26
2021-05-27
2021-05-28
2021-06-01
2021-06-02
2021-06-03
2021-06-04
2021-06-07
2021-06-08
2021-06-09
2021-06-10
2021-06-11
2021-06-14
2021-06-15
2021-06-16
2021-06-17
2021-06-21
2021-06-22
2021-06-23
2021-06-24
2021-06-25
2021-06-28
2021-06-29
2021-06-30
2021-07-01
2021-07-02
2021-07-06
2021-07-07
2021-07-08
2021-07-09
2021-07-12
2021-07-13
2021-07-14
2021-07-15
2021-07-16
2021-07-19
2021-07-20
----------

