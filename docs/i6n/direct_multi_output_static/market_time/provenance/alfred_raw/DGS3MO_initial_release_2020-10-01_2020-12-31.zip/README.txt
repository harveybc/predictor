-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:30 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2020-09-11
2020-09-14
2020-09-15
2020-09-16
2020-09-17
2020-09-18
2020-09-21
2020-09-22
2020-09-23
2020-09-24
2020-09-25
2020-09-28
2020-09-29
2020-09-30
2020-10-01
2020-10-02
2020-10-05
2020-10-06
2020-10-07
2020-10-08
2020-10-09
2020-10-13
2020-10-14
2020-10-15
2020-10-16
2020-10-19
2020-10-20
2020-10-21
2020-10-22
2020-10-23
2020-10-26
2020-10-27
2020-10-28
2020-10-29
2020-10-30
2020-11-02
2020-11-03
2020-11-04
2020-11-05
2020-11-06
2020-11-09
2020-11-10
2020-11-12
2020-11-13
2020-11-16
2020-11-17
2020-11-18
2020-11-19
2020-11-20
2020-11-23
2020-11-24
2020-11-25
2020-11-27
2020-11-30
2020-12-01
2020-12-02
2020-12-03
2020-12-04
2020-12-07
2020-12-08
2020-12-09
2020-12-10
2020-12-11
2020-12-14
2020-12-15
2020-12-16
2020-12-17
2020-12-18
2020-12-21
2020-12-22
2020-12-23
2020-12-28
2020-12-29
2020-12-30
2020-12-31
2021-01-04
2021-01-05
2021-01-06
2021-01-07
2021-01-08
2021-01-11
2021-01-12
2021-01-13
2021-01-14
2021-01-15
2021-01-19
----------

