-------------------------------------------------------------------
Series ID: DGS3MO
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS3MO
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 3-Month Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2023-12-12
2023-12-13
2023-12-14
2023-12-15
2023-12-18
2023-12-19
2023-12-20
2023-12-21
2023-12-22
2023-12-26
2023-12-27
2023-12-28
2023-12-29
2024-01-02
2024-01-03
2024-01-04
2024-01-05
2024-01-08
2024-01-09
2024-01-10
2024-01-11
2024-01-12
2024-01-16
2024-01-17
2024-01-18
2024-01-19
2024-01-22
2024-01-23
2024-01-24
2024-01-25
2024-01-26
2024-01-29
2024-01-30
2024-01-31
2024-02-01
2024-02-02
2024-02-05
2024-02-06
2024-02-07
2024-02-08
2024-02-09
2024-02-12
2024-02-13
2024-02-14
2024-02-15
2024-02-16
2024-02-20
2024-02-21
2024-02-22
2024-02-23
2024-02-26
2024-02-27
2024-02-28
2024-02-29
2024-03-01
2024-03-04
2024-03-05
2024-03-06
2024-03-07
2024-03-08
2024-03-11
2024-03-12
2024-03-13
2024-03-14
2024-03-15
2024-03-18
2024-03-19
2024-03-20
2024-03-21
2024-03-22
2024-03-25
2024-03-26
2024-03-27
2024-03-28
2024-03-29
2024-04-02
2024-04-03
2024-04-04
2024-04-05
2024-04-08
2024-04-09
2024-04-10
2024-04-11
2024-04-12
2024-04-15
2024-04-16
2024-04-17
2024-04-18
2024-04-19
----------

