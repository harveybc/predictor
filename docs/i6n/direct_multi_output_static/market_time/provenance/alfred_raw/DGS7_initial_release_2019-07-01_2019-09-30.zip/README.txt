-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2019-06-11
2019-06-12
2019-06-13
2019-06-14
2019-06-17
2019-06-18
2019-06-19
2019-06-20
2019-06-21
2019-06-24
2019-06-25
2019-06-26
2019-06-27
2019-06-28
2019-07-01
2019-07-02
2019-07-03
2019-07-05
2019-07-08
2019-07-09
2019-07-10
2019-07-11
2019-07-12
2019-07-15
2019-07-16
2019-07-17
2019-07-18
2019-07-19
2019-07-22
2019-07-23
2019-07-24
2019-07-25
2019-07-26
2019-07-29
2019-07-30
2019-07-31
2019-08-01
2019-08-02
2019-08-05
2019-08-06
2019-08-07
2019-08-08
2019-08-09
2019-08-12
2019-08-13
2019-08-14
2019-08-15
2019-08-16
2019-08-19
2019-08-20
2019-08-21
2019-08-22
2019-08-23
2019-08-26
2019-08-27
2019-08-28
2019-08-29
2019-08-30
2019-09-03
2019-09-04
2019-09-05
2019-09-06
2019-09-09
2019-09-10
2019-09-11
2019-09-12
2019-09-13
2019-09-16
2019-09-17
2019-09-18
2019-09-19
2019-09-20
2019-09-23
2019-09-24
2019-09-25
2019-09-26
2019-09-27
2019-09-30
2019-10-01
2019-10-02
2019-10-03
2019-10-04
2019-10-07
2019-10-08
2019-10-09
2019-10-10
2019-10-11
2019-10-15
2019-10-16
2019-10-17
2019-10-18
----------

