-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:31 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2020-12-14
2020-12-15
2020-12-16
2020-12-17
2020-12-18
2020-12-21
2020-12-22
2020-12-23
2020-12-28
2020-12-29
2020-12-30
2020-12-31
2021-01-04
2021-01-05
2021-01-06
2021-01-07
2021-01-08
2021-01-11
2021-01-12
2021-01-13
2021-01-14
2021-01-15
2021-01-19
2021-01-21
2021-01-22
2021-01-25
2021-01-26
2021-01-27
2021-01-28
2021-01-29
2021-02-01
2021-02-02
2021-02-03
2021-02-04
2021-02-05
2021-02-08
2021-02-09
2021-02-10
2021-02-11
2021-02-12
2021-02-16
2021-02-17
2021-02-18
2021-02-19
2021-02-22
2021-02-23
2021-02-24
2021-02-25
2021-02-26
2021-03-01
2021-03-02
2021-03-03
2021-03-04
2021-03-05
2021-03-08
2021-03-09
2021-03-10
2021-03-11
2021-03-12
2021-03-15
2021-03-16
2021-03-17
2021-03-18
2021-03-19
2021-03-22
2021-03-23
2021-03-24
2021-03-25
2021-03-26
2021-03-29
2021-03-30
2021-03-31
2021-04-01
2021-04-02
2021-04-05
2021-04-06
2021-04-07
2021-04-08
2021-04-09
2021-04-12
2021-04-13
2021-04-14
2021-04-15
2021-04-16
2021-04-19
2021-04-20
----------

