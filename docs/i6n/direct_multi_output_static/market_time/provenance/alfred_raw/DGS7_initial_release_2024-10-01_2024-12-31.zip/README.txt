-------------------------------------------------------------------
Series ID: DGS7
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DGS7
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-10-14 10:32 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity,                                                          2014-04-02       Current
Quoted on an Investment Basis
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-06-28       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-06-28       Current
Units
Percent                                                                                                                        2005-06-28       Current
Frequency
Daily                                                                                                                          2005-06-28       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-06-28       Current
Notes
For further information regarding treasury constant maturity data,                                                             2014-04-02       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
H.15 Statistical Release notes                                                                                                 2025-01-07       Current
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
For questions on the data, please contact the data source
(https://www.federalreserve.gov/apps/ContactUs/feedback.aspx?refurl=/releases/h15/%).
For questions on FRED functionality, please contact us here
(https://fred.stlouisfed.org/contactus/).</p>
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2024-09-11
2024-09-12
2024-09-13
2024-09-16
2024-09-17
2024-09-18
2024-09-19
2024-09-20
2024-09-23
2024-09-24
2024-09-25
2024-09-26
2024-09-27
2024-09-30
2024-10-01
2024-10-02
2024-10-03
2024-10-04
2024-10-07
2024-10-08
2024-10-09
2024-10-10
2024-10-11
2024-10-15
2024-10-16
2024-10-17
2024-10-18
2024-10-21
2024-10-22
2024-10-23
2024-10-24
2024-10-25
2024-10-28
2024-10-29
2024-10-30
2024-10-31
2024-11-01
2024-11-04
2024-11-05
2024-11-06
2024-11-07
2024-11-08
2024-11-12
2024-11-13
2024-11-14
2024-11-15
2024-11-18
2024-11-19
2024-11-20
2024-11-21
2024-11-22
2024-11-25
2024-11-26
2024-11-27
2024-11-29
2024-12-02
2024-12-03
2024-12-04
2024-12-05
2024-12-06
2024-12-09
2024-12-10
2024-12-11
2024-12-12
2024-12-13
2024-12-16
2024-12-17
2024-12-18
2024-12-19
2024-12-20
2024-12-23
2024-12-26
2024-12-27
2024-12-30
2024-12-31
2025-01-02
2025-01-03
2025-01-06
2025-01-07
2025-01-08
2025-01-10
2025-01-13
2025-01-14
2025-01-15
2025-01-16
2025-01-17
----------

